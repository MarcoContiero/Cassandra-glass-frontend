//src/components/strategia/StrategiaAIOverlay.tsx
'use client';

import React from 'react';
import { DialogHeader, DialogTitle } from '@/components/ui/dialog';
import SafeDialogContent from '@/components/ui/SafeDialogContent';

// mini-merger di classi tailwind
const cn = (...c: Array<string | false | null | undefined>) => c.filter(Boolean).join(' ');
// ------------ Types ------------
type Dir = 'LONG' | 'SHORT';
type Level = {
  price: number;
  tf?: string;
  forza?: number;
  fonte?: string;
  dist?: number;
};
type Suggestion = {
  dir: Dir;
  kind: 'pullback' | 'breakout';
  entry: number;
  stop?: number;
  tp1?: number;
  tp2?: number;
  tf?: string;
  desc?: string;
  rr?: number | null;
  score?: number;       // punteggio segnale (0-100)
  strengthTag?: 'vicino' | 'forte';
};

function toNum(x: unknown): number | null {
  if (x == null) return null;
  const n = Number(String(x).replace(/[^\d.-]/g, ''));
  return Number.isFinite(n) ? n : null;
}

// ------------ Data access helpers ------------
function winnerDirection(data: any): Dir {
  // 1) fonte diretta, se presente
  const direct = String(
    data?.longshort?.direzione ?? data?.longshort?.direction ?? ''
  ).toUpperCase();
  if (direct === 'LONG' || direct === 'SHORT') return direct as Dir;

  // 2) aggregazione per TF: ***SHORT - LONG*** (attenzione al segno!)
  const tfs = Object.keys(data?.trend_tf_score ?? {});
  if (tfs.length) {
    let acc = 0; // >0 ⇒ SHORT dominante, <0 ⇒ LONG dominante
    for (const tf of tfs) {
      const row = data.trend_tf_score[tf] ?? {};
      const l = Number(row.long ?? 0);
      const s = Number(row.short ?? 0);
      acc += (s - l);                       // <-- qui il segno giusto
    }
    if (acc > 0) return 'SHORT';
    if (acc < 0) return 'LONG';
  }

  // 3) spareggio: delta liquidità (>=0 long, <0 short)
  const delta = Number(
    data?.liquidity_summary?.delta ?? data?.diagnostica?.liquidity_bias?.delta ?? 0
  );
  if (Number.isFinite(delta)) return delta >= 0 ? 'LONG' : 'SHORT';

  // 4) fallback neutro
  return 'LONG';
}

function liquidity(data: any) {
  // struttura attesa dal backend (già presente nel tuo JSON)
  const liq = data?.liquidity ?? {};
  const map = (arr: any[]): Level[] =>
    Array.isArray(arr)
      ? arr.map((v) => {
        const price = toNum(v.livello ?? v.level ?? v.price ?? v.prezzo);
        if (!Number.isFinite(price)) return null;
        return {
          price: price as number,
          tf: v.tf ?? v.timeframe,
          forza: Number.isFinite(Number(v?.forza)) ? Number(v.forza) : undefined,
          fonte: v.source ?? v.fonte ?? v.tipo,
          dist: toNum(v.dist) ?? undefined,
        } as Level;
      }).filter(Boolean) as Level[]
      : [];
  return {
    above: map(liq.sopra ?? liq.above ?? []),
    below: map(liq.sotto ?? liq.below ?? []),
  };
}

function nearest<T extends Level>(levels: T[], price: number, dir: Dir, kind: 'pullback' | 'breakout'): T | null {
  // pullback LONG => livello sotto; breakout LONG => livello sopra
  // pullback SHORT => livello sopra; breakout SHORT => livello sotto
  const candidates =
    dir === 'LONG'
      ? (kind === 'pullback' ? levels.filter(l => l.price < price) : levels.filter(l => l.price > price))
      : (kind === 'pullback' ? levels.filter(l => l.price > price) : levels.filter(l => l.price < price));

  if (!candidates.length) return null;
  const byDist = [...candidates].sort((a, b) => Math.abs(a.price - price) - Math.abs(b.price - price));
  return byDist[0];
}

function strongest(levels: Level[]): Level | null {
  if (!levels.length) return null;
  const withScore = levels.map(l => ({
    l,
    s: (Number.isFinite(l.forza) ? (l.forza as number) : 0) + (l.tf ? tfWeight(l.tf) : 0),
  }));
  withScore.sort((a, b) => b.s - a.s);
  return withScore[0]?.l ?? null;
}

// ------------ Scoring & Confidence ------------
function tfWeight(tf?: string): number {
  if (!tf) return 0;
  const t = tf.toLowerCase();
  if (/(^|\D)15m($|\D)/.test(t)) return 1;
  if (/(^|\D)1h($|\D)/.test(t)) return 2;
  if (/(^|\D)4h($|\D)/.test(t)) return 3;
  if (/1d|1g/i.test(t)) return 4;
  if (/1w/i.test(t)) return 5;
  return 1;
}

function signalScore(entry: number, price: number, level: Level | null, bias: Dir, dir: Dir): number {
  // 0-100: vicinanza (entry più vicino è meglio), forza livello e coerenza col bias globale
  if (!Number.isFinite(entry)) return 0;
  const distAbs = Math.abs(entry - price);
  // normalizza distanza in base al prezzo (0.1% = molto vicino)
  const distPct = (distAbs / price) * 100;
  const nearScore = Math.max(0, 40 - Math.min(distPct * 200, 40)); // 0→40
  const forza = level?.forza ?? 0;
  const tfW = tfWeight(level?.tf) ?? 0;
  const levelScore = Math.min(40, forza * 3 + tfW * 3); // 0→~40
  const biasBonus = bias === dir ? 20 : 5; // 20 se allineato al vincente
  return Math.round(Math.min(100, nearScore + levelScore + biasBonus));
}

function overallConfidence(data: any, tfGuess?: string): number {
  // Blend: trend (0-1) + liquidity delta (0-1) + prossimità media (0-1)
  const tf = tfGuess ?? data?.timeframes?.[0];
  const trend = data?.trend_tf_score?.[tf];
  const tPart = trend ? (Number(trend.score ?? 0) / Number(trend.tot ?? 1)) : 0.5;  // 0-1
  const delta = Math.abs(Number(data?.liquidity_summary?.delta ?? data?.diagnostica?.liquidity_bias?.delta ?? 0));
  const lPart = Math.max(0, Math.min(1, delta / 10)); // ~0-1 dopo clamp
  // Se hai già generato i 3 suggerimenti, ricalcoleremo dPart nel render
  const c = 0.45 * tPart + 0.45 * lPart + 0.10 * 0.5;
  return Math.round(c * 100);
}

// ------------ Builders ------------
function buildSuggestions(data: any): Suggestion[] {
  const px = toNum(data?.prezzo ?? data?.price) ?? 0;
  const liq = liquidity(data);
  const bias = winnerDirection(data);

  const sopra = liq.above;
  const sotto = liq.below;

  // Vicini per ciascuna combinazione utile
  const nearPullLong = nearest(sotto, px, 'LONG', 'pullback');
  const nearBreakLong = nearest(sopra, px, 'LONG', 'breakout');
  const nearPullShort = nearest(sopra, px, 'SHORT', 'pullback');
  const nearBreakShort = nearest(sotto, px, 'SHORT', 'breakout');

  // “Più forte” nella direzione vincente:
  //  - se bias LONG vogliamo tipicamente un rimbalzo credibile => priorità a livelli SOTTO (pullback)
  //  - se bias SHORT priorità a livelli SOPRA (pullback)
  const poolForStrong =
    bias === 'LONG' ? sotto : sopra;
  const strongWin = strongest(poolForStrong); // sceglie per forza/TF

  const out: Suggestion[] = [];
  const push = (dir: Dir, kind: 'pullback' | 'breakout', lvl: Level | null, tag?: 'vicino' | 'forte') => {
    if (!lvl) return;

    // buffer entry per breakout
    const bufferPct = 0.15 / 100;
    const entry =
      dir === 'LONG'
        ? (kind === 'breakout' ? lvl.price * (1 + bufferPct) : lvl.price)
        : (kind === 'breakout' ? lvl.price * (1 - bufferPct) : lvl.price);

    // stop “di sicurezza” (fallback) ±0.35%
    const stop = dir === 'LONG' ? entry * (1 - 0.0035) : entry * (1 + 0.0035);

    // TP: i prossimi 2 livelli nella direzione
    const nexts =
      dir === 'LONG'
        ? [...sopra].filter(l => l.price > entry).sort((a, b) => a.price - b.price).slice(0, 2)
        : [...sotto].filter(l => l.price < entry).sort((a, b) => b.price - a.price).slice(0, 2);

    const tp1 = nexts[0]?.price ?? (dir === 'LONG' ? entry * 1.0075 : entry * 0.9925);
    const tp2 = nexts[1]?.price ?? (dir === 'LONG' ? entry * 1.0175 : entry * 0.9825);

    const s: Suggestion = {
      dir, kind, entry, stop, tp1, tp2,
      tf: lvl.tf,
      desc: lvl.fonte ? (kind === 'pullback' ? `Rimbalzo su ${lvl.fonte}` : `Breakout di ${lvl.fonte}`) : undefined,
      rr: null, score: 0, strengthTag: tag
    };

    s.score = signalScore(entry, px, lvl, bias, dir);
    const risk = Math.abs(entry - (stop as number));
    const reward = Math.abs((tp1 as number) - entry);
    s.rr = risk > 0 ? +(reward / risk).toFixed(2) : null;

    out.push(s);
  };

  // 2 segnali VINVENTI (pullback + breakout)
  if (bias === 'LONG') {
    if (nearPullLong) push('LONG', 'pullback', nearPullLong, 'vicino');
    if (nearBreakLong) push('LONG', 'breakout', nearBreakLong, 'vicino');
  } else {
    if (nearPullShort) push('SHORT', 'pullback', nearPullShort, 'vicino');
    if (nearBreakShort) push('SHORT', 'breakout', nearBreakShort, 'vicino');
  }

  // 1 segnale PERDENTE (il più vicino, qualsiasi tipo)
  const opp = bias === 'LONG'
    ? [['pullback', nearPullShort], ['breakout', nearBreakShort]]
    : [['pullback', nearPullLong], ['breakout', nearBreakLong]];

  const bestOpp = opp
    .filter(([, l]) => !!l)
    .sort((a, b) => Math.abs((a[1] as Level).price - px) - Math.abs((b[1] as Level).price - px))[0];
  if (bestOpp) {
    const kind = bestOpp[0] as 'pullback' | 'breakout';
    const lvl = bestOpp[1] as Level;
    push(bias === 'LONG' ? 'SHORT' : 'LONG', kind, lvl, 'vicino');
  }

  // 1 segnale “PIÙ FORTE” nella direzione vincente (anche se non vicino), preferibilmente pullback
  if (strongWin) {
    const kindPref = 'pullback' as const; // esplicito: vogliamo un rimbalzo “forte”
    push(bias, kindPref, strongWin, 'forte');
  }

  // Ordina per distanza dall’entry al prezzo e posiziona in 2×2
  const ordered = out
    .filter(Boolean)
    .slice(0, 4)
    .sort((a, b) => Math.abs(a.entry - px) - Math.abs(b.entry - px));

  return ordered;
}

// ------------ UI ------------
function Nice({ n }: { n?: number }) {
  if (!Number.isFinite(n as number)) return <>—</>;
  return <>{(n as number).toLocaleString('it-IT')}</>;
}

export default function StrategiaAIOverlay({
  title = 'Strategia AI',
  data,
  className,
}: {
  title?: string;
  data: any;
  className?: string;
}) {
  const overlayTitle = String(title ?? 'Strategia AI');
  const px = toNum(data?.prezzo ?? data?.price) ?? 0;
  const tf = data?.timeframes?.[0] ?? data?.strategia_ai?.items?.[0]?.tf ?? '—';
  const dirWin = winnerDirection(data);
  const cards = buildSuggestions(data);

  const _tfs = Object.keys(data?.trend_tf_score ?? {});
  const _sum = _tfs.reduce((a, tf) => {
    const r = data.trend_tf_score[tf] ?? {};
    return a + (Number(r.short ?? 0) - Number(r.long ?? 0));
  }, 0);
  console.debug('[Bias check] Σ(short-long)=', _sum, '→', _sum > 0 ? 'SHORT' : _sum < 0 ? 'LONG' : 'PARI');

  console.debug('[StrategiaAI] bias UI:', dirWin,
    ' / longshort:', data?.longshort?.direzione,
    ' / agg TF:', Object.keys(data?.trend_tf_score ?? {}).map(tf => ({
      tf, long: data.trend_tf_score[tf]?.long, short: data.trend_tf_score[tf]?.short
    }))
  );

  // calcola confidenza globale (rimpiazzo del 50% fisso)
  const nearAvg = cards.length
    ? cards.reduce((acc, c) => acc + Math.min(1, Math.abs((c.entry - px) / px) / 0.003), 0) / cards.length // 0.3% → 1
    : 0.5;
  const conf = Math.min(100,
    Math.max(5, overallConfidence(data, tf) * 0.6 + (1 - Math.min(1, nearAvg)) * 40)
  );

  // opzione: nascondi “Visione d’insieme” se i dati sono poveri
  const showOverview = Number.isFinite(conf) && cards.length === 3;

  return (
    <SafeDialogContent
      title={overlayTitle}
      description="Tre proposte: due allineate alla direzione vincente e una contraria."
      className={cn(
        "w-[min(96vw,1200px)] sm:max-w-5xl md:max-w-6xl bg-neutral-900 text-neutral-100 border border-neutral-700",
        className
      )}
    >
      <DialogHeader className="pb-2">
        <DialogTitle className="flex items-center gap-2 text-lg">
          <span className="i-lucide-bot w-5 h-5" />
          {overlayTitle} <span className="text-xs px-2 py-0.5 rounded bg-neutral-800/80 border border-neutral-700">TF: {tf}</span>
          <span className="text-xs px-2 py-0.5 rounded bg-neutral-800/80 border border-neutral-700">Bias: {dirWin}</span>
        </DialogTitle>
      </DialogHeader>

      <div className="px-4 pb-3 text-xs text-neutral-400">
        Prezzo attuale: <span className="text-neutral-200">{px.toLocaleString('it-IT')}</span>
      </div>

      {/* Cards */}
      <div className="px-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {cards.map((c, i) => (
          <div key={i} className="rounded-2xl border border-neutral-700 bg-neutral-900/70 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-semibold">
                {c.dir === 'LONG' ? 'Osservazione (long)' : 'Osservazione (short)'}
              </div>
              <div className={`text-xs px-2 py-0.5 rounded ${c.dir === dirWin ? 'bg-emerald-700/30 border border-emerald-600/40' : 'bg-rose-700/20 border border-rose-600/30'}`}>
                {c.dir === dirWin ? 'Vincente' : 'Perdente'}
              </div>
            </div>

            <div className="text-xs text-neutral-400">
              {c.desc ?? (c.kind === 'pullback' ? 'Rimbalzo su livello' : 'Breakout del livello')}
              {c.strengthTag === 'forte' ? ' · alternativa forte' : c.strengthTag === 'vicino' ? ' · vicino' : null}
              {c.tf ? ` · TF ${c.tf}` : null}
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="col-span-2">
                <div className="text-[10px] uppercase text-neutral-400">ENTRY TRIGGER</div>
                <div className="rounded-xl bg-neutral-800/60 p-2 font-medium"><Nice n={c.entry} /></div>
              </div>

              <div>
                <div className="text-[10px] uppercase text-neutral-400">TP1</div>
                <div className="rounded-xl bg-neutral-800/60 p-2"><Nice n={c.tp1} /></div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-neutral-400">TP2</div>
                <div className="rounded-xl bg-neutral-800/60 p-2"><Nice n={c.tp2} /></div>
              </div>

              <div className="col-span-2">
                <div className="text-[10px] uppercase text-neutral-400">Stop</div>
                <div className="rounded-xl bg-neutral-800/60 p-2"><Nice n={c.stop} /></div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <div>Distanza dal prezzo: {Math.abs((c.entry - px) / px * 100).toFixed(2)}%</div>
              <div>RR: {c.rr ?? '—'}</div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div>Punteggio segnale</div>
              <div className="font-semibold">{c.score}%</div>
            </div>

            {/* Alternativa forte (se presente) */}
            {(c as any).__alt_strong ? (
              <div className="text-[11px] text-neutral-400 pt-1">
                Alternativa forte: livello a <Nice n={(c as any).__alt_strong.price} /> {(c as any).__alt_strong.tf ? `(TF ${(c as any).__alt_strong.tf})` : ''}
              </div>
            ) : null}
          </div>
        ))}
      </div>

      {/* ⚡ Alert collegati */}
      {Array.isArray((data as any)?.alerts) && (data as any).alerts.length > 0 && (
        <div className="px-4 mt-4">
          <div className="rounded-2xl border border-neutral-700 bg-neutral-900/70 p-4 space-y-2">
            <div className="text-sm font-medium">⚡ Alert collegati</div>
            <div className="flex flex-wrap gap-2">
              {(data as any).alerts.slice(0, 24).map((a: any, i: number) => (
                <span key={i} className="text-xs px-2 py-0.5 rounded border border-neutral-700 bg-neutral-800/60">
                  {(a.code || a.title || 'ALERT')}{a.tf ? ` · ${a.tf}` : ''}{a.condition ? ` · ${a.condition}` : ''}
                </span>
              ))}
            </div>
            {/* opzionale: lista dettagliata */}
            <div className="text-[11px] text-neutral-400">
              {(data as any).alerts.slice(0, 6).map((a: any, i: number) => (
                <div key={i}>
                  {a.title || a.code} {a.tf ? `(${a.tf})` : ''} {a.price ? `@ ${Number(a.price).toLocaleString('it-IT')}` : ''}
                  {a.time ? ` · ${a.time}` : ''}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 🧠 Motivazioni del segnale */}
      {Array.isArray((data as any)?.motivazioni) && (data as any).motivazioni.length > 0 && (
        <div className="px-4 mt-4">
          <div className="rounded-2xl border border-neutral-700 bg-neutral-900/70 p-4">
            <div className="text-sm font-medium mb-2">🧠 Motivazioni del segnale</div>
            <ul className="text-xs text-neutral-300 space-y-1">
              {(data as any).motivazioni.map((m: string, i: number) => <li key={i}>• {m}</li>)}
            </ul>
          </div>
        </div>
      )}

      {/* Visione d’insieme */}
      {showOverview ? (
        <div className="px-4 mt-4">
          <div className="rounded-2xl border border-neutral-700 bg-neutral-900/70 p-4">
            <div className="text-sm font-medium mb-2">Visione d’insieme</div>
            <div className="text-xs text-neutral-300 flex flex-wrap gap-4">
              <div>Confidenza complessiva: <span className="font-semibold">{conf}%</span></div>
              <div>
                Media RR: <span className="font-semibold">
                  {(() => {
                    const ok = cards.map(c => c.rr).filter((x): x is number => Number.isFinite(x as number));
                    return ok.length ? (ok.reduce((a, b) => a + (b as number), 0) / ok.length).toFixed(2) : '—';
                  })()}
                </span>
              </div>
              <div>Bias: <span className="font-semibold">{dirWin}</span></div>
            </div>
          </div>
        </div>
      ) : null}
    </SafeDialogContent>
  );
}
