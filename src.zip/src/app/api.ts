// src/app/api.ts
// Facciata per evitare ambiguità: TUTTO arriva dal lib.
export * from '../lib/api';
