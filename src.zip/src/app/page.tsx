import ProgramsHub from '@/components/ProgramsHub';

export default function Page() {
  return <ProgramsHub />;
}
