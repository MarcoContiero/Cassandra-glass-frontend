// src/lib/fetchsafeJSON.ts
export * from '../ts/fetchsafeJSON';
export { default } from '../ts/fetchsafeJSON';
