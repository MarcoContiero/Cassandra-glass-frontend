// src/lib/flags.ts
export const flags = {
  ranges: {
    inside: true,
    multitouch: true,
  },
} as const;
