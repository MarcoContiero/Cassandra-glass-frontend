// src/types/index.ts
export type QuestionKey =
  | 'longshort'
  | 'entrate'
  | 'supporti'
  | 'scenari'
  | 'liquidita'
  | 'riepilogo_totale'
  | 'spiegazione'
  | 'trigger_map'
  | 'momentum_gauge';
