'use client';
// shim di compatibilità verso il nuovo path
export { default } from "../strategia/StrategiaAIOverlay";
